function openTab(evt, tabId) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-link').forEach(b => b.classList.remove('active'));
  document.getElementById(tabId).classList.add('active');
  evt.currentTarget.classList.add('active');
}

function previewImage(event) {
  const file = event.target.files[0];
  const preview = document.getElementById("profilePreview");
  if (file) {
    const reader = new FileReader();
    reader.onload = (e) => (preview.src = e.target.result);
    reader.readAsDataURL(file);
  }
}

function togglePassword(icon) {
  const input = icon.previousElementSibling;
  if (input.type === "password") {
    input.type = "text";
    icon.classList.replace("fa-eye", "fa-eye-slash");
  } else {
    input.type = "password";
    icon.classList.replace("fa-eye-slash", "fa-eye");
  }
}

function resetForm() {
  document.getElementById("fullName").value = "";
  document.getElementById("email").value = "";
  document.getElementById("phone").value = "";
  document.getElementById("role").value = "";
  document.getElementById("password").value = "";
  document.getElementById("saveMessage").textContent = "";
}

function saveChanges() {
  const name = document.getElementById("fullName").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const pass = document.getElementById("password").value;
  if (name && email && phone && pass) {
    document.getElementById("saveMessage").textContent = "Account updated successfully!";
  } else {
    document.getElementById("saveMessage").textContent = "Please fill all fields.";
  }
}

function deactivateAccount() {
  const confirmPass = document.getElementById("deactivatePass").value;
  const accountPass = document.getElementById("password").value;

  if (confirmPass === "") {
    document.getElementById("deactivateMessage").textContent = "Please enter your password.";
    return;
  }
  if (confirmPass !== accountPass) {
    document.getElementById("deactivateMessage").textContent = "Password does not match.";
    return;
  }
  document.getElementById("deactivateMessage").textContent = "Account deactivated successfully.";
}
